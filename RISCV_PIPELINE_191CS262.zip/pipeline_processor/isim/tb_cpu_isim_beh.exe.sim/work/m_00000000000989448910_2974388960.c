/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0x7708f090 */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "D:/xilinx/pipeline_processor/register_write.v";
static unsigned int ng1[] = {3U, 0U};
static int ng2[] = {3, 0};
static unsigned int ng3[] = {0U, 0U};
static int ng4[] = {8, 0};
static int ng5[] = {24, 0};
static int ng6[] = {7, 0};
static unsigned int ng7[] = {1U, 0U};
static int ng8[] = {16, 0};
static int ng9[] = {15, 0};
static unsigned int ng10[] = {2U, 0U};
static unsigned int ng11[] = {4U, 0U};
static unsigned int ng12[] = {5U, 0U};



static void Always_30_0(char *t0)
{
    char t6[8];
    char t30[8];
    char t32[16];
    char t36[8];
    char t43[8];
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t7;
    char *t8;
    unsigned int t9;
    unsigned int t10;
    unsigned int t11;
    unsigned int t12;
    unsigned int t13;
    unsigned int t14;
    unsigned int t15;
    unsigned int t16;
    unsigned int t17;
    unsigned int t18;
    unsigned int t19;
    unsigned int t20;
    char *t21;
    char *t22;
    unsigned int t23;
    unsigned int t24;
    unsigned int t25;
    unsigned int t26;
    unsigned int t27;
    char *t28;
    char *t29;
    int t31;
    char *t33;
    char *t34;
    char *t35;
    char *t37;
    char *t38;
    char *t39;
    char *t40;
    char *t41;
    char *t42;
    char *t44;

LAB0:    t1 = (t0 + 3168U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(30, ng0);
    t2 = (t0 + 3488);
    *((int *)t2) = 1;
    t3 = (t0 + 3200);
    *((char **)t3) = t2;
    *((char **)t1) = &&LAB4;

LAB1:    return;
LAB4:    xsi_set_current_line(31, ng0);

LAB5:    xsi_set_current_line(32, ng0);
    t4 = (t0 + 1048U);
    t5 = *((char **)t4);
    t4 = ((char*)((ng1)));
    memset(t6, 0, 8);
    t7 = (t5 + 4);
    t8 = (t4 + 4);
    t9 = *((unsigned int *)t5);
    t10 = *((unsigned int *)t4);
    t11 = (t9 ^ t10);
    t12 = *((unsigned int *)t7);
    t13 = *((unsigned int *)t8);
    t14 = (t12 ^ t13);
    t15 = (t11 | t14);
    t16 = *((unsigned int *)t7);
    t17 = *((unsigned int *)t8);
    t18 = (t16 | t17);
    t19 = (~(t18));
    t20 = (t15 & t19);
    if (t20 != 0)
        goto LAB7;

LAB6:    if (t18 != 0)
        goto LAB8;

LAB9:    t22 = (t6 + 4);
    t23 = *((unsigned int *)t22);
    t24 = (~(t23));
    t25 = *((unsigned int *)t6);
    t26 = (t25 & t24);
    t27 = (t26 != 0);
    if (t27 > 0)
        goto LAB10;

LAB11:    xsi_set_current_line(35, ng0);

LAB13:    xsi_set_current_line(36, ng0);
    t2 = (t0 + 1368U);
    t3 = *((char **)t2);
    memset(t6, 0, 8);
    t2 = (t6 + 4);
    t4 = (t3 + 4);
    t9 = *((unsigned int *)t3);
    t10 = (t9 >> 0);
    *((unsigned int *)t6) = t10;
    t11 = *((unsigned int *)t4);
    t12 = (t11 >> 0);
    *((unsigned int *)t2) = t12;
    t13 = *((unsigned int *)t6);
    *((unsigned int *)t6) = (t13 & 3U);
    t14 = *((unsigned int *)t2);
    *((unsigned int *)t2) = (t14 & 3U);
    t5 = ((char*)((ng2)));
    memset(t30, 0, 8);
    xsi_vlog_unsigned_lshift(t30, 32, t6, 32, t5, 32);
    t7 = (t0 + 2248);
    xsi_vlogvar_assign_value(t7, t30, 0, 0, 32);
    xsi_set_current_line(37, ng0);
    t2 = (t0 + 1208U);
    t3 = *((char **)t2);

LAB14:    t2 = ((char*)((ng3)));
    t31 = xsi_vlog_unsigned_case_compare(t3, 3, t2, 3);
    if (t31 == 1)
        goto LAB15;

LAB16:    t2 = ((char*)((ng7)));
    t31 = xsi_vlog_unsigned_case_compare(t3, 3, t2, 3);
    if (t31 == 1)
        goto LAB17;

LAB18:    t2 = ((char*)((ng10)));
    t31 = xsi_vlog_unsigned_case_compare(t3, 3, t2, 3);
    if (t31 == 1)
        goto LAB19;

LAB20:    t2 = ((char*)((ng11)));
    t31 = xsi_vlog_unsigned_case_compare(t3, 3, t2, 3);
    if (t31 == 1)
        goto LAB21;

LAB22:    t2 = ((char*)((ng12)));
    t31 = xsi_vlog_unsigned_case_compare(t3, 3, t2, 3);
    if (t31 == 1)
        goto LAB23;

LAB24:
LAB25:
LAB12:    goto LAB2;

LAB7:    *((unsigned int *)t6) = 1;
    goto LAB9;

LAB8:    t21 = (t6 + 4);
    *((unsigned int *)t6) = 1;
    *((unsigned int *)t21) = 1;
    goto LAB9;

LAB10:    xsi_set_current_line(33, ng0);
    t28 = (t0 + 1688U);
    t29 = *((char **)t28);
    t28 = (t0 + 2088);
    xsi_vlogvar_assign_value(t28, t29, 0, 0, 64);
    goto LAB12;

LAB15:    xsi_set_current_line(38, ng0);
    t4 = (t0 + 1528U);
    t5 = *((char **)t4);
    t4 = (t0 + 1488U);
    t7 = (t4 + 72U);
    t8 = *((char **)t7);
    t21 = (t0 + 2248);
    t22 = (t21 + 56U);
    t28 = *((char **)t22);
    t29 = ((char*)((ng4)));
    xsi_vlog_get_indexed_partselect(t6, 8, t5, ((int*)(t8)), 2, t28, 32, 2, t29, 32, 1, 1);
    t33 = ((char*)((ng5)));
    t34 = (t0 + 1528U);
    t35 = *((char **)t34);
    t34 = (t0 + 1488U);
    t37 = (t34 + 72U);
    t38 = *((char **)t37);
    t39 = (t0 + 2248);
    t40 = (t39 + 56U);
    t41 = *((char **)t40);
    t42 = ((char*)((ng6)));
    memset(t43, 0, 8);
    xsi_vlog_unsigned_add(t43, 32, t41, 32, t42, 32);
    xsi_vlog_generic_get_index_select_value(t36, 1, t35, t38, 2, t43, 32, 2);
    xsi_vlog_mul_concat(t30, 24, 1, t33, 1U, t36, 1);
    xsi_vlogtype_concat(t32, 64, 32, 2U, t30, 24, t6, 8);
    t44 = (t0 + 2088);
    xsi_vlogvar_assign_value(t44, t32, 0, 0, 64);
    goto LAB25;

LAB17:    xsi_set_current_line(39, ng0);
    t4 = (t0 + 1528U);
    t5 = *((char **)t4);
    t4 = (t0 + 1488U);
    t7 = (t4 + 72U);
    t8 = *((char **)t7);
    t21 = (t0 + 2248);
    t22 = (t21 + 56U);
    t28 = *((char **)t22);
    t29 = ((char*)((ng8)));
    xsi_vlog_get_indexed_partselect(t6, 16, t5, ((int*)(t8)), 2, t28, 32, 2, t29, 32, 1, 1);
    t33 = ((char*)((ng8)));
    t34 = (t0 + 1528U);
    t35 = *((char **)t34);
    t34 = (t0 + 1488U);
    t37 = (t34 + 72U);
    t38 = *((char **)t37);
    t39 = (t0 + 2248);
    t40 = (t39 + 56U);
    t41 = *((char **)t40);
    t42 = ((char*)((ng9)));
    memset(t43, 0, 8);
    xsi_vlog_unsigned_add(t43, 32, t41, 32, t42, 32);
    xsi_vlog_generic_get_index_select_value(t36, 1, t35, t38, 2, t43, 32, 2);
    xsi_vlog_mul_concat(t30, 16, 1, t33, 1U, t36, 1);
    xsi_vlogtype_concat(t32, 64, 32, 2U, t30, 16, t6, 16);
    t44 = (t0 + 2088);
    xsi_vlogvar_assign_value(t44, t32, 0, 0, 64);
    goto LAB25;

LAB19:    xsi_set_current_line(40, ng0);
    t4 = (t0 + 1528U);
    t5 = *((char **)t4);
    t4 = (t0 + 2088);
    xsi_vlogvar_assign_value(t4, t5, 0, 0, 64);
    goto LAB25;

LAB21:    xsi_set_current_line(41, ng0);
    t4 = (t0 + 1528U);
    t5 = *((char **)t4);
    t4 = (t0 + 1488U);
    t7 = (t4 + 72U);
    t8 = *((char **)t7);
    t21 = (t0 + 2248);
    t22 = (t21 + 56U);
    t28 = *((char **)t22);
    t29 = ((char*)((ng4)));
    xsi_vlog_get_indexed_partselect(t6, 8, t5, ((int*)(t8)), 2, t28, 32, 2, t29, 32, 1, 1);
    t33 = ((char*)((ng3)));
    xsi_vlogtype_concat(t32, 64, 32, 2U, t33, 24, t6, 8);
    t34 = (t0 + 2088);
    xsi_vlogvar_assign_value(t34, t32, 0, 0, 64);
    goto LAB25;

LAB23:    xsi_set_current_line(42, ng0);
    t4 = (t0 + 1528U);
    t5 = *((char **)t4);
    t4 = (t0 + 1488U);
    t7 = (t4 + 72U);
    t8 = *((char **)t7);
    t21 = (t0 + 2248);
    t22 = (t21 + 56U);
    t28 = *((char **)t22);
    t29 = ((char*)((ng8)));
    xsi_vlog_get_indexed_partselect(t6, 16, t5, ((int*)(t8)), 2, t28, 32, 2, t29, 32, 1, 1);
    t33 = ((char*)((ng3)));
    xsi_vlogtype_concat(t32, 64, 32, 2U, t33, 16, t6, 16);
    t34 = (t0 + 2088);
    xsi_vlogvar_assign_value(t34, t32, 0, 0, 64);
    goto LAB25;

}


extern void work_m_00000000000989448910_2974388960_init()
{
	static char *pe[] = {(void *)Always_30_0};
	xsi_register_didat("work_m_00000000000989448910_2974388960", "isim/tb_cpu_isim_beh.exe.sim/work/m_00000000000989448910_2974388960.didat");
	xsi_register_executes(pe);
}
