/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0x7708f090 */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "D:/xilinx/pipeline_processor/ID_EX.v";
static int ng1[] = {1, 0};



static void Always_42_0(char *t0)
{
    char t6[8];
    char t30[8];
    char t46[8];
    char t78[8];
    char t79[8];
    char t88[8];
    char t99[8];
    char t130[8];
    char t141[8];
    char t172[8];
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t7;
    char *t8;
    unsigned int t9;
    unsigned int t10;
    unsigned int t11;
    unsigned int t12;
    unsigned int t13;
    unsigned int t14;
    unsigned int t15;
    unsigned int t16;
    unsigned int t17;
    unsigned int t18;
    unsigned int t19;
    unsigned int t20;
    char *t21;
    char *t22;
    unsigned int t23;
    unsigned int t24;
    unsigned int t25;
    unsigned int t26;
    unsigned int t27;
    char *t28;
    char *t29;
    unsigned int t31;
    unsigned int t32;
    unsigned int t33;
    unsigned int t34;
    unsigned int t35;
    unsigned int t36;
    int t37;
    int t38;
    unsigned int t39;
    unsigned int t40;
    unsigned int t41;
    unsigned int t42;
    unsigned int t43;
    unsigned int t44;
    char *t45;
    unsigned int t47;
    unsigned int t48;
    unsigned int t49;
    char *t50;
    char *t51;
    unsigned int t52;
    unsigned int t53;
    unsigned int t54;
    unsigned int t55;
    unsigned int t56;
    unsigned int t57;
    unsigned int t58;
    char *t59;
    char *t60;
    unsigned int t61;
    unsigned int t62;
    unsigned int t63;
    unsigned int t64;
    unsigned int t65;
    unsigned int t66;
    unsigned int t67;
    unsigned int t68;
    int t69;
    int t70;
    unsigned int t71;
    unsigned int t72;
    unsigned int t73;
    unsigned int t74;
    unsigned int t75;
    unsigned int t76;
    char *t77;
    char *t80;
    char *t81;
    char *t82;
    unsigned int t83;
    unsigned int t84;
    unsigned int t85;
    unsigned int t86;
    unsigned int t87;
    char *t89;
    char *t90;
    unsigned int t91;
    unsigned int t92;
    unsigned int t93;
    unsigned int t94;
    unsigned int t95;
    char *t96;
    char *t97;
    char *t98;
    unsigned int t100;
    unsigned int t101;
    unsigned int t102;
    char *t103;
    char *t104;
    unsigned int t105;
    unsigned int t106;
    unsigned int t107;
    unsigned int t108;
    unsigned int t109;
    unsigned int t110;
    unsigned int t111;
    char *t112;
    char *t113;
    unsigned int t114;
    unsigned int t115;
    unsigned int t116;
    unsigned int t117;
    unsigned int t118;
    unsigned int t119;
    unsigned int t120;
    unsigned int t121;
    int t122;
    int t123;
    unsigned int t124;
    unsigned int t125;
    unsigned int t126;
    unsigned int t127;
    unsigned int t128;
    unsigned int t129;
    char *t131;
    char *t132;
    unsigned int t133;
    unsigned int t134;
    unsigned int t135;
    unsigned int t136;
    unsigned int t137;
    char *t138;
    char *t139;
    char *t140;
    unsigned int t142;
    unsigned int t143;
    unsigned int t144;
    char *t145;
    char *t146;
    unsigned int t147;
    unsigned int t148;
    unsigned int t149;
    unsigned int t150;
    unsigned int t151;
    unsigned int t152;
    unsigned int t153;
    char *t154;
    char *t155;
    unsigned int t156;
    unsigned int t157;
    unsigned int t158;
    unsigned int t159;
    unsigned int t160;
    unsigned int t161;
    unsigned int t162;
    unsigned int t163;
    int t164;
    int t165;
    unsigned int t166;
    unsigned int t167;
    unsigned int t168;
    unsigned int t169;
    unsigned int t170;
    unsigned int t171;
    unsigned int t173;
    unsigned int t174;
    unsigned int t175;
    char *t176;
    char *t177;
    char *t178;
    unsigned int t179;
    unsigned int t180;
    unsigned int t181;
    unsigned int t182;
    unsigned int t183;
    unsigned int t184;
    unsigned int t185;
    char *t186;
    char *t187;
    unsigned int t188;
    unsigned int t189;
    unsigned int t190;
    unsigned int t191;
    unsigned int t192;
    unsigned int t193;
    unsigned int t194;
    unsigned int t195;
    int t196;
    int t197;
    unsigned int t198;
    unsigned int t199;
    unsigned int t200;
    unsigned int t201;
    unsigned int t202;
    unsigned int t203;
    char *t204;

LAB0:    t1 = (t0 + 6528U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(42, ng0);
    t2 = (t0 + 6848);
    *((int *)t2) = 1;
    t3 = (t0 + 6560);
    *((char **)t3) = t2;
    *((char **)t1) = &&LAB4;

LAB1:    return;
LAB4:    xsi_set_current_line(43, ng0);

LAB5:    xsi_set_current_line(44, ng0);
    t4 = (t0 + 1208U);
    t5 = *((char **)t4);
    t4 = ((char*)((ng1)));
    memset(t6, 0, 8);
    t7 = (t5 + 4);
    t8 = (t4 + 4);
    t9 = *((unsigned int *)t5);
    t10 = *((unsigned int *)t4);
    t11 = (t9 ^ t10);
    t12 = *((unsigned int *)t7);
    t13 = *((unsigned int *)t8);
    t14 = (t12 ^ t13);
    t15 = (t11 | t14);
    t16 = *((unsigned int *)t7);
    t17 = *((unsigned int *)t8);
    t18 = (t16 | t17);
    t19 = (~(t18));
    t20 = (t15 & t19);
    if (t20 != 0)
        goto LAB9;

LAB6:    if (t18 != 0)
        goto LAB8;

LAB7:    *((unsigned int *)t6) = 1;

LAB9:    t22 = (t6 + 4);
    t23 = *((unsigned int *)t22);
    t24 = (~(t23));
    t25 = *((unsigned int *)t6);
    t26 = (t25 & t24);
    t27 = (t26 != 0);
    if (t27 > 0)
        goto LAB10;

LAB11:
LAB12:    goto LAB2;

LAB8:    t21 = (t6 + 4);
    *((unsigned int *)t6) = 1;
    *((unsigned int *)t21) = 1;
    goto LAB9;

LAB10:    xsi_set_current_line(45, ng0);

LAB13:    xsi_set_current_line(46, ng0);
    t28 = (t0 + 2328U);
    t29 = *((char **)t28);
    t28 = (t0 + 4168);
    xsi_vlogvar_assign_value(t28, t29, 0, 0, 5);
    xsi_set_current_line(47, ng0);
    t2 = (t0 + 2488U);
    t3 = *((char **)t2);
    t2 = (t0 + 4328);
    xsi_vlogvar_assign_value(t2, t3, 0, 0, 5);
    xsi_set_current_line(48, ng0);
    t2 = (t0 + 2648U);
    t3 = *((char **)t2);
    t2 = (t0 + 4488);
    xsi_vlogvar_assign_value(t2, t3, 0, 0, 5);
    xsi_set_current_line(49, ng0);
    t2 = (t0 + 2808U);
    t3 = *((char **)t2);
    t2 = (t0 + 4648);
    xsi_vlogvar_assign_value(t2, t3, 0, 0, 3);
    xsi_set_current_line(50, ng0);
    t2 = (t0 + 2968U);
    t3 = *((char **)t2);
    t2 = (t0 + 4808);
    xsi_vlogvar_assign_value(t2, t3, 0, 0, 7);
    xsi_set_current_line(51, ng0);
    t2 = (t0 + 3288U);
    t3 = *((char **)t2);
    t2 = (t0 + 5608);
    xsi_vlogvar_assign_value(t2, t3, 0, 0, 64);
    xsi_set_current_line(52, ng0);
    t2 = (t0 + 2168U);
    t3 = *((char **)t2);
    t2 = (t0 + 5288);
    xsi_vlogvar_assign_value(t2, t3, 0, 0, 32);
    xsi_set_current_line(53, ng0);
    t2 = (t0 + 1688U);
    t3 = *((char **)t2);
    t2 = (t0 + 1368U);
    t4 = *((char **)t2);
    memset(t6, 0, 8);
    t2 = (t4 + 4);
    t9 = *((unsigned int *)t2);
    t10 = (~(t9));
    t11 = *((unsigned int *)t4);
    t12 = (t11 & t10);
    t13 = (t12 & 1U);
    if (t13 != 0)
        goto LAB17;

LAB15:    if (*((unsigned int *)t2) == 0)
        goto LAB14;

LAB16:    t5 = (t6 + 4);
    *((unsigned int *)t6) = 1;
    *((unsigned int *)t5) = 1;

LAB17:    t14 = *((unsigned int *)t3);
    t15 = *((unsigned int *)t6);
    t16 = (t14 & t15);
    *((unsigned int *)t30) = t16;
    t7 = (t3 + 4);
    t8 = (t6 + 4);
    t21 = (t30 + 4);
    t17 = *((unsigned int *)t7);
    t18 = *((unsigned int *)t8);
    t19 = (t17 | t18);
    *((unsigned int *)t21) = t19;
    t20 = *((unsigned int *)t21);
    t23 = (t20 != 0);
    if (t23 == 1)
        goto LAB18;

LAB19:
LAB20:    t29 = (t0 + 1208U);
    t45 = *((char **)t29);
    t47 = *((unsigned int *)t30);
    t48 = *((unsigned int *)t45);
    t49 = (t47 & t48);
    *((unsigned int *)t46) = t49;
    t29 = (t30 + 4);
    t50 = (t45 + 4);
    t51 = (t46 + 4);
    t52 = *((unsigned int *)t29);
    t53 = *((unsigned int *)t50);
    t54 = (t52 | t53);
    *((unsigned int *)t51) = t54;
    t55 = *((unsigned int *)t51);
    t56 = (t55 != 0);
    if (t56 == 1)
        goto LAB21;

LAB22:
LAB23:    t77 = (t0 + 3848);
    xsi_vlogvar_assign_value(t77, t46, 0, 0, 1);
    xsi_set_current_line(54, ng0);
    t2 = (t0 + 3128U);
    t3 = *((char **)t2);
    t2 = (t0 + 1368U);
    t4 = *((char **)t2);
    memset(t30, 0, 8);
    t2 = (t4 + 4);
    t9 = *((unsigned int *)t2);
    t10 = (~(t9));
    t11 = *((unsigned int *)t4);
    t12 = (t11 & t10);
    t13 = (t12 & 1U);
    if (t13 != 0)
        goto LAB27;

LAB25:    if (*((unsigned int *)t2) == 0)
        goto LAB24;

LAB26:    t5 = (t30 + 4);
    *((unsigned int *)t30) = 1;
    *((unsigned int *)t5) = 1;

LAB27:    t7 = (t0 + 1208U);
    t8 = *((char **)t7);
    t14 = *((unsigned int *)t30);
    t15 = *((unsigned int *)t8);
    t16 = (t14 & t15);
    *((unsigned int *)t46) = t16;
    t7 = (t30 + 4);
    t21 = (t8 + 4);
    t22 = (t46 + 4);
    t17 = *((unsigned int *)t7);
    t18 = *((unsigned int *)t21);
    t19 = (t17 | t18);
    *((unsigned int *)t22) = t19;
    t20 = *((unsigned int *)t22);
    t23 = (t20 != 0);
    if (t23 == 1)
        goto LAB28;

LAB29:
LAB30:    t45 = (t0 + 1368U);
    t50 = *((char **)t45);
    memset(t78, 0, 8);
    t45 = (t50 + 4);
    t47 = *((unsigned int *)t45);
    t48 = (~(t47));
    t49 = *((unsigned int *)t50);
    t52 = (t49 & t48);
    t53 = (t52 & 1U);
    if (t53 != 0)
        goto LAB34;

LAB32:    if (*((unsigned int *)t45) == 0)
        goto LAB31;

LAB33:    t51 = (t78 + 4);
    *((unsigned int *)t78) = 1;
    *((unsigned int *)t51) = 1;

LAB34:    t59 = (t0 + 1208U);
    t60 = *((char **)t59);
    t54 = *((unsigned int *)t78);
    t55 = *((unsigned int *)t60);
    t56 = (t54 & t55);
    *((unsigned int *)t79) = t56;
    t59 = (t78 + 4);
    t77 = (t60 + 4);
    t80 = (t79 + 4);
    t57 = *((unsigned int *)t59);
    t58 = *((unsigned int *)t77);
    t61 = (t57 | t58);
    *((unsigned int *)t80) = t61;
    t62 = *((unsigned int *)t80);
    t63 = (t62 != 0);
    if (t63 == 1)
        goto LAB35;

LAB36:
LAB37:    t89 = (t0 + 1368U);
    t90 = *((char **)t89);
    memset(t88, 0, 8);
    t89 = (t90 + 4);
    t91 = *((unsigned int *)t89);
    t92 = (~(t91));
    t93 = *((unsigned int *)t90);
    t94 = (t93 & t92);
    t95 = (t94 & 1U);
    if (t95 != 0)
        goto LAB41;

LAB39:    if (*((unsigned int *)t89) == 0)
        goto LAB38;

LAB40:    t96 = (t88 + 4);
    *((unsigned int *)t88) = 1;
    *((unsigned int *)t96) = 1;

LAB41:    t97 = (t0 + 1208U);
    t98 = *((char **)t97);
    t100 = *((unsigned int *)t88);
    t101 = *((unsigned int *)t98);
    t102 = (t100 & t101);
    *((unsigned int *)t99) = t102;
    t97 = (t88 + 4);
    t103 = (t98 + 4);
    t104 = (t99 + 4);
    t105 = *((unsigned int *)t97);
    t106 = *((unsigned int *)t103);
    t107 = (t105 | t106);
    *((unsigned int *)t104) = t107;
    t108 = *((unsigned int *)t104);
    t109 = (t108 != 0);
    if (t109 == 1)
        goto LAB42;

LAB43:
LAB44:    t131 = (t0 + 1368U);
    t132 = *((char **)t131);
    memset(t130, 0, 8);
    t131 = (t132 + 4);
    t133 = *((unsigned int *)t131);
    t134 = (~(t133));
    t135 = *((unsigned int *)t132);
    t136 = (t135 & t134);
    t137 = (t136 & 1U);
    if (t137 != 0)
        goto LAB48;

LAB46:    if (*((unsigned int *)t131) == 0)
        goto LAB45;

LAB47:    t138 = (t130 + 4);
    *((unsigned int *)t130) = 1;
    *((unsigned int *)t138) = 1;

LAB48:    t139 = (t0 + 1208U);
    t140 = *((char **)t139);
    t142 = *((unsigned int *)t130);
    t143 = *((unsigned int *)t140);
    t144 = (t142 & t143);
    *((unsigned int *)t141) = t144;
    t139 = (t130 + 4);
    t145 = (t140 + 4);
    t146 = (t141 + 4);
    t147 = *((unsigned int *)t139);
    t148 = *((unsigned int *)t145);
    t149 = (t147 | t148);
    *((unsigned int *)t146) = t149;
    t150 = *((unsigned int *)t146);
    t151 = (t150 != 0);
    if (t151 == 1)
        goto LAB49;

LAB50:
LAB51:    xsi_vlogtype_concat(t6, 4, 4, 4U, t141, 1, t99, 1, t79, 1, t46, 1);
    t173 = *((unsigned int *)t3);
    t174 = *((unsigned int *)t6);
    t175 = (t173 & t174);
    *((unsigned int *)t172) = t175;
    t176 = (t3 + 4);
    t177 = (t6 + 4);
    t178 = (t172 + 4);
    t179 = *((unsigned int *)t176);
    t180 = *((unsigned int *)t177);
    t181 = (t179 | t180);
    *((unsigned int *)t178) = t181;
    t182 = *((unsigned int *)t178);
    t183 = (t182 != 0);
    if (t183 == 1)
        goto LAB52;

LAB53:
LAB54:    t204 = (t0 + 5448);
    xsi_vlogvar_assign_value(t204, t172, 0, 0, 4);
    xsi_set_current_line(55, ng0);
    t2 = (t0 + 1848U);
    t3 = *((char **)t2);
    t2 = (t0 + 4968);
    xsi_vlogvar_assign_value(t2, t3, 0, 0, 64);
    xsi_set_current_line(56, ng0);
    t2 = (t0 + 2008U);
    t3 = *((char **)t2);
    t2 = (t0 + 5128);
    xsi_vlogvar_assign_value(t2, t3, 0, 0, 64);
    xsi_set_current_line(57, ng0);
    t2 = (t0 + 1528U);
    t3 = *((char **)t2);
    t2 = (t0 + 3688);
    xsi_vlogvar_assign_value(t2, t3, 0, 0, 1);
    xsi_set_current_line(58, ng0);
    t2 = (t0 + 1208U);
    t3 = *((char **)t2);
    t2 = (t0 + 4008);
    xsi_vlogvar_assign_value(t2, t3, 0, 0, 1);
    goto LAB12;

LAB14:    *((unsigned int *)t6) = 1;
    goto LAB17;

LAB18:    t24 = *((unsigned int *)t30);
    t25 = *((unsigned int *)t21);
    *((unsigned int *)t30) = (t24 | t25);
    t22 = (t3 + 4);
    t28 = (t6 + 4);
    t26 = *((unsigned int *)t3);
    t27 = (~(t26));
    t31 = *((unsigned int *)t22);
    t32 = (~(t31));
    t33 = *((unsigned int *)t6);
    t34 = (~(t33));
    t35 = *((unsigned int *)t28);
    t36 = (~(t35));
    t37 = (t27 & t32);
    t38 = (t34 & t36);
    t39 = (~(t37));
    t40 = (~(t38));
    t41 = *((unsigned int *)t21);
    *((unsigned int *)t21) = (t41 & t39);
    t42 = *((unsigned int *)t21);
    *((unsigned int *)t21) = (t42 & t40);
    t43 = *((unsigned int *)t30);
    *((unsigned int *)t30) = (t43 & t39);
    t44 = *((unsigned int *)t30);
    *((unsigned int *)t30) = (t44 & t40);
    goto LAB20;

LAB21:    t57 = *((unsigned int *)t46);
    t58 = *((unsigned int *)t51);
    *((unsigned int *)t46) = (t57 | t58);
    t59 = (t30 + 4);
    t60 = (t45 + 4);
    t61 = *((unsigned int *)t30);
    t62 = (~(t61));
    t63 = *((unsigned int *)t59);
    t64 = (~(t63));
    t65 = *((unsigned int *)t45);
    t66 = (~(t65));
    t67 = *((unsigned int *)t60);
    t68 = (~(t67));
    t69 = (t62 & t64);
    t70 = (t66 & t68);
    t71 = (~(t69));
    t72 = (~(t70));
    t73 = *((unsigned int *)t51);
    *((unsigned int *)t51) = (t73 & t71);
    t74 = *((unsigned int *)t51);
    *((unsigned int *)t51) = (t74 & t72);
    t75 = *((unsigned int *)t46);
    *((unsigned int *)t46) = (t75 & t71);
    t76 = *((unsigned int *)t46);
    *((unsigned int *)t46) = (t76 & t72);
    goto LAB23;

LAB24:    *((unsigned int *)t30) = 1;
    goto LAB27;

LAB28:    t24 = *((unsigned int *)t46);
    t25 = *((unsigned int *)t22);
    *((unsigned int *)t46) = (t24 | t25);
    t28 = (t30 + 4);
    t29 = (t8 + 4);
    t26 = *((unsigned int *)t30);
    t27 = (~(t26));
    t31 = *((unsigned int *)t28);
    t32 = (~(t31));
    t33 = *((unsigned int *)t8);
    t34 = (~(t33));
    t35 = *((unsigned int *)t29);
    t36 = (~(t35));
    t37 = (t27 & t32);
    t38 = (t34 & t36);
    t39 = (~(t37));
    t40 = (~(t38));
    t41 = *((unsigned int *)t22);
    *((unsigned int *)t22) = (t41 & t39);
    t42 = *((unsigned int *)t22);
    *((unsigned int *)t22) = (t42 & t40);
    t43 = *((unsigned int *)t46);
    *((unsigned int *)t46) = (t43 & t39);
    t44 = *((unsigned int *)t46);
    *((unsigned int *)t46) = (t44 & t40);
    goto LAB30;

LAB31:    *((unsigned int *)t78) = 1;
    goto LAB34;

LAB35:    t64 = *((unsigned int *)t79);
    t65 = *((unsigned int *)t80);
    *((unsigned int *)t79) = (t64 | t65);
    t81 = (t78 + 4);
    t82 = (t60 + 4);
    t66 = *((unsigned int *)t78);
    t67 = (~(t66));
    t68 = *((unsigned int *)t81);
    t71 = (~(t68));
    t72 = *((unsigned int *)t60);
    t73 = (~(t72));
    t74 = *((unsigned int *)t82);
    t75 = (~(t74));
    t69 = (t67 & t71);
    t70 = (t73 & t75);
    t76 = (~(t69));
    t83 = (~(t70));
    t84 = *((unsigned int *)t80);
    *((unsigned int *)t80) = (t84 & t76);
    t85 = *((unsigned int *)t80);
    *((unsigned int *)t80) = (t85 & t83);
    t86 = *((unsigned int *)t79);
    *((unsigned int *)t79) = (t86 & t76);
    t87 = *((unsigned int *)t79);
    *((unsigned int *)t79) = (t87 & t83);
    goto LAB37;

LAB38:    *((unsigned int *)t88) = 1;
    goto LAB41;

LAB42:    t110 = *((unsigned int *)t99);
    t111 = *((unsigned int *)t104);
    *((unsigned int *)t99) = (t110 | t111);
    t112 = (t88 + 4);
    t113 = (t98 + 4);
    t114 = *((unsigned int *)t88);
    t115 = (~(t114));
    t116 = *((unsigned int *)t112);
    t117 = (~(t116));
    t118 = *((unsigned int *)t98);
    t119 = (~(t118));
    t120 = *((unsigned int *)t113);
    t121 = (~(t120));
    t122 = (t115 & t117);
    t123 = (t119 & t121);
    t124 = (~(t122));
    t125 = (~(t123));
    t126 = *((unsigned int *)t104);
    *((unsigned int *)t104) = (t126 & t124);
    t127 = *((unsigned int *)t104);
    *((unsigned int *)t104) = (t127 & t125);
    t128 = *((unsigned int *)t99);
    *((unsigned int *)t99) = (t128 & t124);
    t129 = *((unsigned int *)t99);
    *((unsigned int *)t99) = (t129 & t125);
    goto LAB44;

LAB45:    *((unsigned int *)t130) = 1;
    goto LAB48;

LAB49:    t152 = *((unsigned int *)t141);
    t153 = *((unsigned int *)t146);
    *((unsigned int *)t141) = (t152 | t153);
    t154 = (t130 + 4);
    t155 = (t140 + 4);
    t156 = *((unsigned int *)t130);
    t157 = (~(t156));
    t158 = *((unsigned int *)t154);
    t159 = (~(t158));
    t160 = *((unsigned int *)t140);
    t161 = (~(t160));
    t162 = *((unsigned int *)t155);
    t163 = (~(t162));
    t164 = (t157 & t159);
    t165 = (t161 & t163);
    t166 = (~(t164));
    t167 = (~(t165));
    t168 = *((unsigned int *)t146);
    *((unsigned int *)t146) = (t168 & t166);
    t169 = *((unsigned int *)t146);
    *((unsigned int *)t146) = (t169 & t167);
    t170 = *((unsigned int *)t141);
    *((unsigned int *)t141) = (t170 & t166);
    t171 = *((unsigned int *)t141);
    *((unsigned int *)t141) = (t171 & t167);
    goto LAB51;

LAB52:    t184 = *((unsigned int *)t172);
    t185 = *((unsigned int *)t178);
    *((unsigned int *)t172) = (t184 | t185);
    t186 = (t3 + 4);
    t187 = (t6 + 4);
    t188 = *((unsigned int *)t3);
    t189 = (~(t188));
    t190 = *((unsigned int *)t186);
    t191 = (~(t190));
    t192 = *((unsigned int *)t6);
    t193 = (~(t192));
    t194 = *((unsigned int *)t187);
    t195 = (~(t194));
    t196 = (t189 & t191);
    t197 = (t193 & t195);
    t198 = (~(t196));
    t199 = (~(t197));
    t200 = *((unsigned int *)t178);
    *((unsigned int *)t178) = (t200 & t198);
    t201 = *((unsigned int *)t178);
    *((unsigned int *)t178) = (t201 & t199);
    t202 = *((unsigned int *)t172);
    *((unsigned int *)t172) = (t202 & t198);
    t203 = *((unsigned int *)t172);
    *((unsigned int *)t172) = (t203 & t199);
    goto LAB54;

}


extern void work_m_00000000003002604657_0103510313_init()
{
	static char *pe[] = {(void *)Always_42_0};
	xsi_register_didat("work_m_00000000003002604657_0103510313", "isim/tb_cpu_isim_beh.exe.sim/work/m_00000000003002604657_0103510313.didat");
	xsi_register_executes(pe);
}
