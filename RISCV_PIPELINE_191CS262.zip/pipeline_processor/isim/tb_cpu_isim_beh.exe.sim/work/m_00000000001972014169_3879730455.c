/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0x7708f090 */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "D:/xilinx/pipeline_processor/Immed_wr.v";
static unsigned int ng1[] = {51U, 0U};
static int ng2[] = {1, 0};
static unsigned int ng3[] = {0U, 0U};
static unsigned int ng4[] = {19U, 0U};
static int ng5[] = {52, 0};
static unsigned int ng6[] = {3U, 0U};
static unsigned int ng7[] = {35U, 0U};
static int ng8[] = {0, 0};
static unsigned int ng9[] = {1U, 0U};
static unsigned int ng10[] = {2U, 0U};
static unsigned int ng11[] = {15U, 0U};
static unsigned int ng12[] = {99U, 0U};



static void Always_27_0(char *t0)
{
    char t4[8];
    char t18[16];
    char t19[8];
    char t20[16];
    char t21[8];
    char t30[8];
    char t39[24];
    char t40[8];
    char t42[8];
    char t53[8];
    char *t1;
    char *t2;
    char *t3;
    char *t5;
    char *t6;
    char *t7;
    unsigned int t8;
    unsigned int t9;
    unsigned int t10;
    unsigned int t11;
    unsigned int t12;
    unsigned int t13;
    char *t14;
    int t15;
    char *t16;
    char *t17;
    unsigned int t22;
    unsigned int t23;
    unsigned int t24;
    unsigned int t25;
    unsigned int t26;
    unsigned int t27;
    char *t28;
    char *t29;
    char *t31;
    unsigned int t32;
    unsigned int t33;
    unsigned int t34;
    unsigned int t35;
    unsigned int t36;
    unsigned int t37;
    char *t38;
    char *t41;
    char *t43;
    unsigned int t44;
    unsigned int t45;
    unsigned int t46;
    unsigned int t47;
    unsigned int t48;
    unsigned int t49;
    char *t50;
    char *t51;
    char *t52;
    char *t54;
    unsigned int t55;
    unsigned int t56;
    unsigned int t57;
    unsigned int t58;
    unsigned int t59;
    unsigned int t60;
    char *t61;

LAB0:    t1 = (t0 + 2688U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(27, ng0);
    t2 = (t0 + 3008);
    *((int *)t2) = 1;
    t3 = (t0 + 2720);
    *((char **)t3) = t2;
    *((char **)t1) = &&LAB4;

LAB1:    return;
LAB4:    xsi_set_current_line(28, ng0);

LAB5:    xsi_set_current_line(29, ng0);
    t5 = (t0 + 1048U);
    t6 = *((char **)t5);
    memset(t4, 0, 8);
    t5 = (t4 + 4);
    t7 = (t6 + 4);
    t8 = *((unsigned int *)t6);
    t9 = (t8 >> 0);
    *((unsigned int *)t4) = t9;
    t10 = *((unsigned int *)t7);
    t11 = (t10 >> 0);
    *((unsigned int *)t5) = t11;
    t12 = *((unsigned int *)t4);
    *((unsigned int *)t4) = (t12 & 127U);
    t13 = *((unsigned int *)t5);
    *((unsigned int *)t5) = (t13 & 127U);

LAB6:    t14 = ((char*)((ng1)));
    t15 = xsi_vlog_unsigned_case_compare(t4, 7, t14, 7);
    if (t15 == 1)
        goto LAB7;

LAB8:    t2 = ((char*)((ng4)));
    t15 = xsi_vlog_unsigned_case_compare(t4, 7, t2, 7);
    if (t15 == 1)
        goto LAB9;

LAB10:    t2 = ((char*)((ng6)));
    t15 = xsi_vlog_unsigned_case_compare(t4, 7, t2, 7);
    if (t15 == 1)
        goto LAB11;

LAB12:    t2 = ((char*)((ng7)));
    t15 = xsi_vlog_unsigned_case_compare(t4, 7, t2, 7);
    if (t15 == 1)
        goto LAB13;

LAB14:    t2 = ((char*)((ng12)));
    t15 = xsi_vlog_unsigned_case_compare(t4, 7, t2, 7);
    if (t15 == 1)
        goto LAB15;

LAB16:
LAB17:    goto LAB2;

LAB7:    xsi_set_current_line(31, ng0);

LAB18:    xsi_set_current_line(32, ng0);
    t16 = ((char*)((ng2)));
    t17 = (t0 + 1768);
    xsi_vlogvar_assign_value(t17, t16, 0, 0, 1);
    xsi_set_current_line(33, ng0);
    t2 = ((char*)((ng3)));
    t3 = (t0 + 1448);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 4);
    goto LAB17;

LAB9:    xsi_set_current_line(36, ng0);

LAB19:    xsi_set_current_line(37, ng0);
    t3 = (t0 + 1048U);
    t5 = *((char **)t3);
    memset(t19, 0, 8);
    t3 = (t19 + 4);
    t6 = (t5 + 4);
    t8 = *((unsigned int *)t5);
    t9 = (t8 >> 20);
    *((unsigned int *)t19) = t9;
    t10 = *((unsigned int *)t6);
    t11 = (t10 >> 20);
    *((unsigned int *)t3) = t11;
    t12 = *((unsigned int *)t19);
    *((unsigned int *)t19) = (t12 & 4095U);
    t13 = *((unsigned int *)t3);
    *((unsigned int *)t3) = (t13 & 4095U);
    t7 = ((char*)((ng5)));
    t14 = (t0 + 1048U);
    t16 = *((char **)t14);
    memset(t21, 0, 8);
    t14 = (t21 + 4);
    t17 = (t16 + 4);
    t22 = *((unsigned int *)t16);
    t23 = (t22 >> 31);
    t24 = (t23 & 1);
    *((unsigned int *)t21) = t24;
    t25 = *((unsigned int *)t17);
    t26 = (t25 >> 31);
    t27 = (t26 & 1);
    *((unsigned int *)t14) = t27;
    xsi_vlog_mul_concat(t20, 52, 1, t7, 1U, t21, 1);
    xsi_vlogtype_concat(t18, 64, 64, 2U, t20, 52, t19, 12);
    t28 = (t0 + 1608);
    xsi_vlogvar_assign_value(t28, t18, 0, 0, 64);
    xsi_set_current_line(38, ng0);
    t2 = ((char*)((ng2)));
    t3 = (t0 + 1768);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 1);
    xsi_set_current_line(39, ng0);
    t2 = ((char*)((ng3)));
    t3 = (t0 + 1448);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 4);
    goto LAB17;

LAB11:    xsi_set_current_line(42, ng0);

LAB20:    xsi_set_current_line(44, ng0);
    t3 = (t0 + 1048U);
    t5 = *((char **)t3);
    memset(t19, 0, 8);
    t3 = (t19 + 4);
    t6 = (t5 + 4);
    t8 = *((unsigned int *)t5);
    t9 = (t8 >> 20);
    *((unsigned int *)t19) = t9;
    t10 = *((unsigned int *)t6);
    t11 = (t10 >> 20);
    *((unsigned int *)t3) = t11;
    t12 = *((unsigned int *)t19);
    *((unsigned int *)t19) = (t12 & 4095U);
    t13 = *((unsigned int *)t3);
    *((unsigned int *)t3) = (t13 & 4095U);
    t7 = ((char*)((ng5)));
    t14 = (t0 + 1048U);
    t16 = *((char **)t14);
    memset(t21, 0, 8);
    t14 = (t21 + 4);
    t17 = (t16 + 4);
    t22 = *((unsigned int *)t16);
    t23 = (t22 >> 31);
    t24 = (t23 & 1);
    *((unsigned int *)t21) = t24;
    t25 = *((unsigned int *)t17);
    t26 = (t25 >> 31);
    t27 = (t26 & 1);
    *((unsigned int *)t14) = t27;
    xsi_vlog_mul_concat(t20, 52, 1, t7, 1U, t21, 1);
    xsi_vlogtype_concat(t18, 64, 64, 2U, t20, 52, t19, 12);
    t28 = (t0 + 1608);
    xsi_vlogvar_assign_value(t28, t18, 0, 0, 64);
    xsi_set_current_line(45, ng0);
    t2 = ((char*)((ng2)));
    t3 = (t0 + 1768);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 1);
    xsi_set_current_line(46, ng0);
    t2 = ((char*)((ng3)));
    t3 = (t0 + 1448);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 4);
    goto LAB17;

LAB13:    xsi_set_current_line(49, ng0);

LAB21:    xsi_set_current_line(50, ng0);
    t3 = (t0 + 1048U);
    t5 = *((char **)t3);
    memset(t19, 0, 8);
    t3 = (t19 + 4);
    t6 = (t5 + 4);
    t8 = *((unsigned int *)t5);
    t9 = (t8 >> 7);
    *((unsigned int *)t19) = t9;
    t10 = *((unsigned int *)t6);
    t11 = (t10 >> 7);
    *((unsigned int *)t3) = t11;
    t12 = *((unsigned int *)t19);
    *((unsigned int *)t19) = (t12 & 31U);
    t13 = *((unsigned int *)t3);
    *((unsigned int *)t3) = (t13 & 31U);
    t7 = (t0 + 1048U);
    t14 = *((char **)t7);
    memset(t21, 0, 8);
    t7 = (t21 + 4);
    t16 = (t14 + 4);
    t22 = *((unsigned int *)t14);
    t23 = (t22 >> 25);
    *((unsigned int *)t21) = t23;
    t24 = *((unsigned int *)t16);
    t25 = (t24 >> 25);
    *((unsigned int *)t7) = t25;
    t26 = *((unsigned int *)t21);
    *((unsigned int *)t21) = (t26 & 127U);
    t27 = *((unsigned int *)t7);
    *((unsigned int *)t7) = (t27 & 127U);
    t17 = ((char*)((ng5)));
    t28 = (t0 + 1048U);
    t29 = *((char **)t28);
    memset(t30, 0, 8);
    t28 = (t30 + 4);
    t31 = (t29 + 4);
    t32 = *((unsigned int *)t29);
    t33 = (t32 >> 31);
    t34 = (t33 & 1);
    *((unsigned int *)t30) = t34;
    t35 = *((unsigned int *)t31);
    t36 = (t35 >> 31);
    t37 = (t36 & 1);
    *((unsigned int *)t28) = t37;
    xsi_vlog_mul_concat(t20, 52, 1, t17, 1U, t30, 1);
    xsi_vlogtype_concat(t18, 64, 64, 3U, t20, 52, t21, 7, t19, 5);
    t38 = (t0 + 1608);
    xsi_vlogvar_assign_value(t38, t18, 0, 0, 64);
    xsi_set_current_line(51, ng0);
    t2 = ((char*)((ng8)));
    t3 = (t0 + 1768);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 1);
    xsi_set_current_line(52, ng0);
    t2 = (t0 + 1048U);
    t3 = *((char **)t2);
    memset(t19, 0, 8);
    t2 = (t19 + 4);
    t5 = (t3 + 4);
    t8 = *((unsigned int *)t3);
    t9 = (t8 >> 12);
    *((unsigned int *)t19) = t9;
    t10 = *((unsigned int *)t5);
    t11 = (t10 >> 12);
    *((unsigned int *)t2) = t11;
    t12 = *((unsigned int *)t19);
    *((unsigned int *)t19) = (t12 & 7U);
    t13 = *((unsigned int *)t2);
    *((unsigned int *)t2) = (t13 & 7U);

LAB22:    t6 = ((char*)((ng3)));
    t15 = xsi_vlog_unsigned_case_compare(t19, 3, t6, 3);
    if (t15 == 1)
        goto LAB23;

LAB24:    t2 = ((char*)((ng9)));
    t15 = xsi_vlog_unsigned_case_compare(t19, 3, t2, 3);
    if (t15 == 1)
        goto LAB25;

LAB26:    t2 = ((char*)((ng10)));
    t15 = xsi_vlog_unsigned_case_compare(t19, 3, t2, 3);
    if (t15 == 1)
        goto LAB27;

LAB28:
LAB29:    goto LAB17;

LAB15:    xsi_set_current_line(59, ng0);

LAB30:    xsi_set_current_line(60, ng0);
    t3 = ((char*)((ng3)));
    t5 = (t0 + 1048U);
    t6 = *((char **)t5);
    memset(t21, 0, 8);
    t5 = (t21 + 4);
    t7 = (t6 + 4);
    t8 = *((unsigned int *)t6);
    t9 = (t8 >> 8);
    *((unsigned int *)t21) = t9;
    t10 = *((unsigned int *)t7);
    t11 = (t10 >> 8);
    *((unsigned int *)t5) = t11;
    t12 = *((unsigned int *)t21);
    *((unsigned int *)t21) = (t12 & 15U);
    t13 = *((unsigned int *)t5);
    *((unsigned int *)t5) = (t13 & 15U);
    t14 = (t0 + 1048U);
    t16 = *((char **)t14);
    memset(t30, 0, 8);
    t14 = (t30 + 4);
    t17 = (t16 + 4);
    t22 = *((unsigned int *)t16);
    t23 = (t22 >> 25);
    *((unsigned int *)t30) = t23;
    t24 = *((unsigned int *)t17);
    t25 = (t24 >> 25);
    *((unsigned int *)t14) = t25;
    t26 = *((unsigned int *)t30);
    *((unsigned int *)t30) = (t26 & 63U);
    t27 = *((unsigned int *)t14);
    *((unsigned int *)t14) = (t27 & 63U);
    t28 = (t0 + 1048U);
    t29 = *((char **)t28);
    memset(t40, 0, 8);
    t28 = (t40 + 4);
    t31 = (t29 + 4);
    t32 = *((unsigned int *)t29);
    t33 = (t32 >> 7);
    t34 = (t33 & 1);
    *((unsigned int *)t40) = t34;
    t35 = *((unsigned int *)t31);
    t36 = (t35 >> 7);
    t37 = (t36 & 1);
    *((unsigned int *)t28) = t37;
    t38 = (t0 + 1048U);
    t41 = *((char **)t38);
    memset(t42, 0, 8);
    t38 = (t42 + 4);
    t43 = (t41 + 4);
    t44 = *((unsigned int *)t41);
    t45 = (t44 >> 31);
    t46 = (t45 & 1);
    *((unsigned int *)t42) = t46;
    t47 = *((unsigned int *)t43);
    t48 = (t47 >> 31);
    t49 = (t48 & 1);
    *((unsigned int *)t38) = t49;
    t50 = ((char*)((ng5)));
    t51 = (t0 + 1048U);
    t52 = *((char **)t51);
    memset(t53, 0, 8);
    t51 = (t53 + 4);
    t54 = (t52 + 4);
    t55 = *((unsigned int *)t52);
    t56 = (t55 >> 31);
    t57 = (t56 & 1);
    *((unsigned int *)t53) = t57;
    t58 = *((unsigned int *)t54);
    t59 = (t58 >> 31);
    t60 = (t59 & 1);
    *((unsigned int *)t51) = t60;
    xsi_vlog_mul_concat(t18, 52, 1, t50, 1U, t53, 1);
    xsi_vlogtype_concat(t39, 65, 65, 6U, t18, 52, t42, 1, t40, 1, t30, 6, t21, 4, t3, 1);
    t61 = (t0 + 1608);
    xsi_vlogvar_assign_value(t61, t39, 0, 0, 64);
    xsi_set_current_line(61, ng0);
    t2 = ((char*)((ng8)));
    t3 = (t0 + 1768);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 1);
    xsi_set_current_line(62, ng0);
    t2 = ((char*)((ng3)));
    t3 = (t0 + 1448);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 4);
    goto LAB17;

LAB23:    xsi_set_current_line(53, ng0);
    t7 = ((char*)((ng9)));
    t14 = (t0 + 1448);
    xsi_vlogvar_assign_value(t14, t7, 0, 0, 4);
    goto LAB29;

LAB25:    xsi_set_current_line(54, ng0);
    t3 = ((char*)((ng6)));
    t5 = (t0 + 1448);
    xsi_vlogvar_assign_value(t5, t3, 0, 0, 4);
    goto LAB29;

LAB27:    xsi_set_current_line(55, ng0);
    t3 = ((char*)((ng11)));
    t5 = (t0 + 1448);
    xsi_vlogvar_assign_value(t5, t3, 0, 0, 4);
    goto LAB29;

}


extern void work_m_00000000001972014169_3879730455_init()
{
	static char *pe[] = {(void *)Always_27_0};
	xsi_register_didat("work_m_00000000001972014169_3879730455", "isim/tb_cpu_isim_beh.exe.sim/work/m_00000000001972014169_3879730455.didat");
	xsi_register_executes(pe);
}
